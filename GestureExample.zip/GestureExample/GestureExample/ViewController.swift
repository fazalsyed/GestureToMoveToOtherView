//
//  ViewController.swift
//  GestureExample
//
//  Created by syed fazal abbas on 10/05/23.
//

import UIKit

class ViewController: UIViewController {
    let gesture = UITapGestureRecognizer()
    override func viewDidLoad() {
        super.viewDidLoad()
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes(_:)))
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes(_:)))
        let upSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes(_:)))
        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipes(_:)))
        
        leftSwipe.direction = .left
        rightSwipe.direction = .right
        upSwipe.direction = .up
        downSwipe.direction = .down
        
        
        view.addGestureRecognizer(leftSwipe)
        view.addGestureRecognizer(rightSwipe)
        view.addGestureRecognizer(upSwipe)
        view.addGestureRecognizer(downSwipe)
    }
    
    @objc func handleSwipes(_ sender: UISwipeGestureRecognizer){
        if sender.direction == .left{
            performSegue(withIdentifier: "Left", sender: self)
        }
        else if sender.direction == .right{
            performSegue(withIdentifier: "Right", sender: self)
        }
        else if sender.direction == .up{
            performSegue(withIdentifier: "Up", sender: self)
        }
        else if sender.direction == .down{
            performSegue(withIdentifier: "Down", sender: self)
        }
    }
}

